'''
ai_swe2_dva_project_daily/weekly/ta data
test models with asset classes & TA data
'''

import tensorflow as tf
from tensorflow import keras
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import classification_report
from sklearn import metrics

tf.logging.set_verbosity(tf.logging.FATAL)

custModClData = []
custModRegData = []
dnnRegModData = []
dnnClModData = []
LinClModData = []
epochs = 100
sp_steps = 1
	
def guessCol(gCol):#creates stock, bond, usd guess/direction columns
	gCol = gCol.copy()
	for i in range(len(gCol)-1):
		if  gCol.iloc[i] > 0:
			gCol.iloc[i] = 1
		elif  gCol.iloc[i] == 0:
			gCol.iloc[i] = 2
		elif  gCol.iloc[i] < 0:
			gCol.iloc[i] = 0
	return gCol
	
def maCreation(df, type, col):#creates simple moving averages
	df['%s_MA_5' % type] = df['%s' % col].rolling(window=5).mean()
	df['%s_MA_10' % type] = df['%s' % col].rolling(window=10).mean()
	df['%s_MA_20' % type] = df['%s' % col].rolling(window=20).mean()
	df['%s_MA_40' % type] = df['%s' % col].rolling(window=40).mean()
	
def customModelTrain(x, y, output, epochs, data):#custom models (classification & regression)
	print('With Custom Model')
	scaler = MinMaxScaler()
	y = y.reset_index(drop=True)#remove date data type index since it is not compatible with tensorflow
	x = x.reset_index(drop=True)
	sc_x = pd.DataFrame(scaler.fit_transform(x), columns=x.columns, index=x.index)
	x_train, x_test, y_train, y_test = train_test_split(sc_x, y, test_size= .30, shuffle=False)
	print('Data shapes (x_train, x_test, y_train, y_test...): ', x_train.shape, x_test.shape, y_train.shape, y_test.shape)
	#Build model
	model3 = keras.Sequential([
		keras.layers.Dense(50,input_shape=(x_train.shape[1:])), 
		keras.layers.Dense(256,activation=tf.nn.relu),
		keras.layers.Dense(128,activation=tf.nn.relu), 
		keras.layers.Dense(output,activation=tf.nn.softmax)])
	#compile model
	model3.compile(optimizer=tf.train.AdamOptimizer(), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
	#train model
	#print('TRAINING CUSTOM MODEL....')
	model3.fit(x_train, y_train, batch_size=None,epochs=epochs, verbose=0, shuffle=True, steps_per_epoch=sp_steps)
	#evaluate model
	eval_results = model3.evaluate(x_test, y_test)
	#print('MODEL EVALUATION...')
	data.append(eval_results)
	#print(data)
	#model predictions
	predictions = model3.predict(x_test)
	return data
	
def trainModelDNNreg(X, y, f_cols, epochs):#dnn regression model
	#print('With DNNRegressor')
	scaler = MinMaxScaler()#scaler obj for normalizing data
	y = y.reset_index(drop=True)#remove date data type index since it is not compatible with tensorflow
	X = X.reset_index(drop=True)#remove date data type index since it is not compatible with tensorflow
	X = pd.DataFrame(data=scaler.fit_transform(X),columns=X.columns, index=X.index)#normalize data
	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, shuffle=False) #train/test split
	model = tf.estimator.DNNRegressor(hidden_units=[256,128], feature_columns=f_cols) #create estimator
	train_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_train, y=y_train, batch_size=100, num_epochs=None, shuffle=True) #train model setup
	training = model.train(input_fn=train_input_fn, steps=epochs)#,hooks=[logging_hook]) #train model
	plt.show(training)
	eval_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_test, y=y_test, num_epochs=1, shuffle=False) #model evaluation setup
	eval_results = model.evaluate(input_fn=eval_input_fn) #evaluate model
	#print(eval_results)
	dnnRegModData.append(eval_results)
	pred_fn = tf.estimator.inputs.pandas_input_fn(x=X_test,batch_size=len(X_test),shuffle=False)#prediction fn input
	predictions = list(model.predict(input_fn=pred_fn, yield_single_examples=True))#make predictions
	
def trainModelDNNclass(X, y, f_cols, epochs):#dnn classification model
	#print('With DNNClassification')
	scaler = MinMaxScaler()
	y = y.reset_index(drop=True)
	X = X.reset_index(drop=True)
	X = pd.DataFrame(data=scaler.fit_transform(X),columns=X.columns, index=X.index)
	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, shuffle=False) #train/test split
	model = tf.estimator.DNNClassifier(hidden_units=[256,128,64], feature_columns=f_cols,n_classes=3)#,dnn_dropout=.1)
									#,dnn_optimizer='') #create estimator
	train_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_train, y=y_train, batch_size=100, num_epochs=None, shuffle=True) #train model setup
	model.train(input_fn=train_input_fn, steps=epochs)
	eval_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_test, y=y_test, num_epochs=1, shuffle=False) #model evaluation setup
	eval_results = model.evaluate(input_fn=eval_input_fn) #evaluate model
	#print(eval_results)
	dnnClModData.append(eval_results)
	pred_fn = tf.estimator.inputs.pandas_input_fn(x=X_test,batch_size=len(X_test),shuffle=False)#prediction fn input
	predictions = model.predict(input_fn=pred_fn)#make predictions
	
def trainModelLinclass(X, y, f_cols, epochs):#linear classification model
	#print('With LinearClassification')
	scaler = MinMaxScaler()
	y = y.reset_index(drop=True)
	X = X.reset_index(drop=True)
	X = pd.DataFrame(data=scaler.fit_transform(X),columns=X.columns, index=X.index)
	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, shuffle=False) #train/test split
	model = tf.estimator.LinearClassifier(feature_columns=f_cols,n_classes=3) #create estimator
	train_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_train, y=y_train, batch_size=100, num_epochs=None, shuffle=True) #train model setup
	model.train(input_fn=train_input_fn, steps=epochs)#,hooks=[logging_hook])#train model
	eval_input_fn = tf.estimator.inputs.pandas_input_fn(x=X_test, y=y_test, num_epochs=1, shuffle=False) #model evaluation setup
	eval_results = model.evaluate(input_fn=eval_input_fn) #evaluate model
	#print(eval_results)
	LinClModData.append(eval_results)
	pred_fn = tf.estimator.inputs.pandas_input_fn(x=X_test,batch_size=len(X_test),shuffle=False)#prediction fn input
	predictions = model.predict(input_fn=pred_fn)#make predictions
	#print(predictions)
	
def bondModelRunner(df, f_cols, model_num, str):
	bb = pd.DataFrame(df).dropna()
	by = bb['US_10_yr_bond']
	bb = bb.drop(columns=['US_10_yr_bond'])
	#using stocks & interest rates to guess bond direction
	bb2 = pd.DataFrame(df).dropna()
	by2 = bb2['Bond_Guess'].astype('int32')
	bb2 = bb2.drop(columns=['Bond_Guess'])
	#models using stocks & interest rates to guess bond price
	print('BOND PRICE PREDICTION MODEL (with %s + TA)...model set %d' % (str, model_num))
	trainModelDNNreg(bb, by, f_cols, epochs)
	#models using stocks & interest rates to guess bond direction
	print('BOND DIRECTION PREDICTION MODEL (with %s + TA)' % str)
	trainModelDNNclass(bb2, by2, f_cols, epochs)
	trainModelLinclass(bb2, by2, f_cols, epochs)
	customModelTrain(bb, by, 20, epochs, custModRegData)
	customModelTrain(bb2, by2, 3, epochs, custModClData)
	
def stockModelRunner(df, f_cols, model_num, str):
	bs = pd.DataFrame(df).dropna()
	ba = bs['Close']
	bs = bs.drop(columns=['Close'])
	bs2 = pd.DataFrame(df).dropna()
	ba2 = bs2['Stock_Guess'].astype('int32')
	bs2 = bs2.drop(columns=['Stock_Guess'])
	print('STOCK PRICE PREDICTION MODEL (with %s + TA)...model set %d' % (str, model_num))
	trainModelDNNreg(bs, ba, f_cols, epochs)
	print('STOCK DIRECTION PREDICTION MODEL (with %s + TA)' % str)
	trainModelDNNclass(bs2, ba2, f_cols, epochs)
	trainModelLinclass(bs2, ba2, f_cols, epochs)
	customModelTrain(bs, ba, 3000, epochs, custModRegData)
	customModelTrain(bs2, ba2, 3, epochs, custModClData)
	
def usdModelRunner(df, f_cols, model_num, str):
	#using stocks, ir, & bonds to guess usd price
	sib = pd.DataFrame(df).dropna()
	sibb = sib['Usd_Index']
	sib = sib.drop(columns=['Usd_Index'])
	#using stocks, ir, & bonds to guess usd direction
	sib2 = pd.DataFrame(df).dropna()
	sibb2 = sib2['Usd_Guess'].astype('int32')
	sib2 = sib2.drop(columns=['Usd_Guess'])
	#using stocks, ir, & bonds to guess usd price
	print('USD PRICE PREDICTION MODEL (with %s + TA)...model set %d' % (str, model_num))
	trainModelDNNreg(sib, sibb, f_cols, epochs)
	#models using stocks, ir, & bonds to guess usd direction
	print('USD DIRECTION PREDICTION MODEL (with %s + TA)' % str)
	trainModelDNNclass(sib2, sibb2, f_cols, epochs)
	trainModelLinclass(sib2, sibb2, f_cols, epochs)
	customModelTrain(sib, sibb, 200, epochs, custModRegData)
	customModelTrain(sib2, sibb2, 3, epochs, custModClData)

def dataCleaning():#prepares/cleans data
	#DATA IMPORTS
	#import daily datasets; will convert to weekly sets
	bonds_ir = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/FRB_H15-edit.csv')
	stocks = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/SNP500/snp500-daily-1950.csv')
	gold = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/GOLDPMGBD228NLBM.csv')
	usd = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/tw-USD-index-mc_daily-1973.csv')
	ted = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/TEDRATE-daily-1986.csv')
	m3libor = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/3-month-LIBOR-daily-1986.csv')
	vix = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/VIX-fred-daily-1990.csv')
	crb = pd.DataFrame.from_csv('/home/sim/Coding/tf-progs/Fall18_projects/datasets/daily_intraday/RICI-RICI_crb-index-daily-1998.csv')

	#DATA CLEANING: column renaming & removing NaNs
	#change column names
	gold = gold.rename(columns={"GOLDPMGBD228NLBM": "Gold_Prices"})
	usd = usd.rename(columns={"DTWEXM": "Usd_Index"})
	ted = ted.rename(columns={"TEDRATE": "Ted_Rate"})
	m3libor = m3libor.rename(columns={"USD3MTD156N": "LIBOR_3_Month"})
	vix = vix.rename(columns={"VIXCLS": "Vix_Index"})
	crb = crb.rename(columns={"Value": "Crb_Index"})

	#change column data types
	gold['Gold_Prices'] = gold.Gold_Prices.replace('.', -1.00).astype(float)
	gold['Gold_Prices'] = gold.Gold_Prices.replace(-1.00, np.nan)
	usd['Usd_Index'] = usd.Usd_Index.replace('.', -1.00).astype(float)
	usd['Usd_Index'] = usd.Usd_Index.replace(-1.00, np.nan)
	ted['Ted_Rate'] = ted.Ted_Rate.replace('.', -1.00).astype(float)
	ted['Ted_Rate'] = ted.Ted_Rate.replace(-1.00, np.nan)
	m3libor['LIBOR_3_Month'] = m3libor.LIBOR_3_Month.replace('.', -1.00).astype(float)
	m3libor['LIBOR_3_Month'] = m3libor.LIBOR_3_Month.replace(-1.00, np.nan)
	vix['Vix_Index'] = vix.Vix_Index.replace('.', -1.00).astype(float)
	vix['Vix_Index'] = vix.Vix_Index.replace(-1.00, np.nan)

	#clean bond & ir data with individual DFs
	bonds = pd.DataFrame(bonds_ir['Federal funds effective rate'])
	ir = pd.DataFrame(bonds_ir['10-year US bond yield'])
	ir = ir.dropna()
	b_ir = pd.DataFrame.merge(bonds,ir,on='DATE')

	#clean bond/interest rate data and rename column names
	b_ir = b_ir.replace('ND', -1.00)
	b_ir = b_ir.fillna(-1.00)
	b_ir = b_ir.rename(columns={"10-year US bond yield": "US_10_yr_bond", "Federal funds effective rate": "Feds_IR"})
	b_ir['US_10_yr_bond'] = b_ir.US_10_yr_bond.astype(float)
	b_ir['Feds_IR'] = b_ir.Feds_IR.astype(float)
	b_ir = b_ir.replace(-1.00, np.nan)

	#MERGING CLEAN DATA TO PRODUCE DATAFRAMES
	#clean bond, ir, & stock DF (daily)
	bis_D_org = pd.DataFrame.merge(stocks,b_ir,on='DATE')
	bis_D = bis_D_org.copy()
	
	#create column for guessing bond & stock direction (1 for up: 2 for equal: 0 for down)
	bis_D['Bond_Guess'] = pd.DataFrame(bis_D['US_10_yr_bond'].diff())
	bis_D['Bond_Guess'] = guessCol(bis_D['Bond_Guess'])
	bis_D['Stock_Guess'] = pd.DataFrame(bis_D['Close'].diff())
	bis_D['Stock_Guess'] = guessCol(bis_D['Stock_Guess'])
	#ta(technical analysis) data creation (simple moving averages [5, 10, 20, & 40] for stocks & bonds)
	maCreation(bis_D, 'Stock', 'Adj Close')
	maCreation(bis_D, 'Bond', 'US_10_yr_bond')
	#clean daily bond, ir, stock, & gold data
	b_g_D_org = pd.DataFrame.merge(bis_D,gold,on='DATE')
	b_g_D = b_g_D_org.copy()
	#clean daily bond, ir, stock, & usd data
	b_u_D_org = pd.DataFrame.merge(bis_D,usd,on='DATE')
	b_u_D = b_u_D_org.copy()
	#clean daily bond, ir, stock, gold & usd data
	bg_u_D_org = pd.DataFrame.merge(b_g_D,usd,on='DATE')
	bg_u_D = bg_u_D_org.copy()
	#create column for guessing usd direction (1 for up: 2 for equal: 0 for down)
	bg_u_D['Usd_Guess'] = pd.DataFrame(bg_u_D['Usd_Index'].diff())
	bg_u_D['Usd_Guess'] = guessCol(bg_u_D['Usd_Guess'])
	#ta data creation (simple moving averages [5, 10, 20, & 40] for usd)
	maCreation(bg_u_D, 'USA', 'Usd_Index')

	#clean daily bond, ir, stocks, gold, usd, & TED
	bgu_ted_D_org = pd.DataFrame.merge(bg_u_D,ted,on='DATE')
	bgu_ted_D = bgu_ted_D_org.copy()
	#clean daily bond, ir, stocks, gold, usd, & 3-month-LIBOR
	bgu_m3_D_org = pd.DataFrame.merge(bg_u_D,m3libor,on='DATE')
	bgu_m3_D = bgu_m3_D_org.copy()
	#clean daily bond, ir, stocks, gold, usd, TED & 3-month-LIBOR
	bgu_ted_m3_D_org = pd.DataFrame.merge(bgu_ted_D,m3libor,on='DATE')
	bgu_ted_m3_D = bgu_ted_m3_D_org.copy()
	#clean daily bond, ir, stocks, gold, usd, TED, 3-month-LIBOR & VIX
	bt3m_vix_D_org = pd.DataFrame.merge(bgu_ted_m3_D,vix,on='DATE')
	bt3m_vix_D = bt3m_vix_D_org.copy()
	#clean daily bond, ir, stocks, gold, usd, TED, 3-month-LIBOR, VIX, & CRB
	bv_crb_D_org = pd.DataFrame.merge(bt3m_vix_D,crb,on='DATE')
	bv_crb_D = bv_crb_D_org.copy()
	
	#WEEKLY DATA CREATION FROM DAILY DATA
	#weekly clean bond, ir, & stock DF
	bis_W = bis_D_org.iloc[3::5]
	#create column for guessing bond, stock, & usd direction (1 for up: 0 for equal: -1 for down)
	bis_W['Bond_Guess'] = pd.DataFrame(bis_W['US_10_yr_bond'].diff())
	bis_W['Bond_Guess'] = guessCol(bis_W['Bond_Guess'])
	bis_W['Stock_Guess'] = pd.DataFrame(bis_W['Close'].diff())
	bis_W['Stock_Guess'] = guessCol(bis_W['Stock_Guess'])
	#ta data creation (simple moving averages [5, 10, 20, & 40] for stocks, bonds, & usd)
	maCreation(bis_W, 'Stock', 'Adj Close')
	maCreation(bis_W, 'Bond', 'US_10_yr_bond')
	b_g_W = b_g_D_org.iloc[3::5]
	b_u_W = b_u_D_org.iloc[3::5]
	bg_u_W = bg_u_D_org.iloc[3::5]
	bg_u_W['Usd_Guess'] = pd.DataFrame(bg_u_W['Usd_Index'].diff())
	bg_u_W['Usd_Guess'] = guessCol(bg_u_W['Usd_Guess'])
	maCreation(bg_u_W, 'USA', 'Usd_Index')
	bgu_ted_W = bgu_ted_D_org.iloc[3::5]
	bgu_m3_W = bgu_m3_D_org.iloc[3::5]
	bgu_ted_m3_W = bgu_ted_m3_D_org.iloc[3::5]
	bt3m_vix_W = bt3m_vix_D_org.iloc[3::5]
	bv_crb_W = bv_crb_D_org.iloc[3::5]
	print('####################')
	print('IGNORE WARNINGS ABOVE')
	print('####################')
	
	return bis_D, b_g_D, b_u_D, bg_u_D, bgu_ted_D, bgu_m3_D, bgu_ted_m3_D, bt3m_vix_D, bv_crb_D
	
		
def main(unused_argv):#main code execution
	bis_D, b_g_D, b_u_D, bg_u_D, bgu_ted_D, bgu_m3_D, bgu_ted_m3_D, bt3m_vix_D, bv_crb_D = dataCleaning()
	
	#MODEL TRAINING PREPERATION
	#feature_columns to use for tf model
	#set of 2
	open = tf.feature_column.numeric_column('Open')
	high = tf.feature_column.numeric_column('High')
	low = tf.feature_column.numeric_column('Low')
	close = tf.feature_column.numeric_column('Close')
	volume = tf.feature_column.numeric_column('Volume')
	fir = tf.feature_column.numeric_column('Feds_IR')
	bond = tf.feature_column.numeric_column('US_10_yr_bond')
	gold = tf.feature_column.numeric_column('Gold_Prices')
	usd = tf.feature_column.numeric_column('Usd_Index')
	ted = tf.feature_column.numeric_column('Ted_Rate')
	lib3m = tf.feature_column.numeric_column('LIBOR_3_Month')
	vix = tf.feature_column.numeric_column('Vix_Index')
	crb = tf.feature_column.numeric_column('Crb_Index')
	st_m_5 = tf.feature_column.numeric_column('Stock_MA_5')
	st_m_10 = tf.feature_column.numeric_column('Stock_MA_10')
	st_m_20 = tf.feature_column.numeric_column('Stock_MA_20')
	st_m_40 = tf.feature_column.numeric_column('Stock_MA_40')
	b_m_5 = tf.feature_column.numeric_column('Bond_MA_5')
	b_m_10 = tf.feature_column.numeric_column('Bond_MA_10')
	b_m_20 = tf.feature_column.numeric_column('Bond_MA_20')
	b_m_40 = tf.feature_column.numeric_column('Bond_MA_40')
	u_m_5 = tf.feature_column.numeric_column('USA_MA_5')
	u_m_10 = tf.feature_column.numeric_column('USA_MA_10')
	u_m_20 = tf.feature_column.numeric_column('USA_MA_20')
	u_m_40 = tf.feature_column.numeric_column('USA_MA_40')
	
	#CONSTRUCT DATA TO FEED MODELS
	st_cols = [open, low, close, volume, fir, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bis_D, st_cols, 1, 'stocks & interest rates')
	
	bi_cols = [bond, fir, b_m_5, b_m_10, b_m_20, b_m_40]	
	stockModelRunner(bis_D, bi_cols, 2, 'bonds & interest rates')
	
	big_cols = [bond, fir, gold, b_m_5, b_m_10, b_m_20, b_m_40]
	stockModelRunner(bg_u_D, big_cols, 3, 'bonds, ir, & gold')
	
	sig_cols = [open, high, low, close, volume, fir, gold, st_m_5, st_m_10, st_m_20, st_m_40] 
	bondModelRunner(b_g_D, sig_cols, 4, 'stocks, ir, & gold')
	
	sib_cols = [open, high, low, close, volume, fir, bond, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40] 
	usdModelRunner(bg_u_D, sib_cols, 5, 'stocks, ir, & bonds')
	
	siu_cols = [open, high, low, close, volume, fir, usd, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bg_u_D, siu_cols, 6, 'stocks, ir, usd')
	
	biu_cols = [bond,fir,usd, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bg_u_D, biu_cols, 7, 'bonds, ir, usd')
	
	biug_cols = [bond,fir,usd,gold, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bg_u_D, biug_cols, 8, 'bonds, ir, usd, gold')
	
	sibg_cols = [open, high, low, close, volume, fir, bond, gold, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bg_u_D, sibg_cols, 9, 'stocks, ir, bonds, gold')
	
	sigu_cols = [open, high, low, close, volume, fir, gold, usd, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bg_u_D, sigu_cols, 10, 'stocks, ir, gold, usd')
	
	biugt_cols = [bond,fir,usd,gold, ted, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bgu_ted_D, biugt_cols, 11, 'bonds, ir, usd, gold, ted')

	sibgt_cols = [open, high, low, close, volume, fir, bond, gold, ted, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bgu_ted_D, sibgt_cols, 12, 'stocks, ir, bonds, gold, ted')
	
	sigut_cols = [open, high, low, close, volume, fir, gold, usd, ted, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bgu_ted_D, sigut_cols, 13, 'stocks, ir, gold, usd, ted')
	
	biugl_cols = [bond,fir,usd,gold, lib3m, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bgu_m3_D, biugl_cols, 14, 'bonds, ir, usd, gold, lib3m')

	sibgl_cols = [open, high, low, close, volume, fir, bond, gold, lib3m, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bgu_m3_D, sibgl_cols, 15, 'stocks, ir, bonds, gold, lib3m')
	
	sigul_cols = [open, high, low, close, volume, fir, gold, usd, lib3m, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bgu_m3_D, sigul_cols, 16, 'stocks, ir, gold, usd, lib3m')
	
	biuglt_cols = [bond,fir,usd,gold, lib3m, ted, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bgu_ted_m3_D, biuglt_cols, 17, 'bonds, ir, usd, gold, lib3m, ted')
	
	sibglt_cols = [open, high, low, close, volume, fir, bond, gold, lib3m, ted, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bgu_ted_m3_D, sibglt_cols, 18, 'stocks, ir, bonds, gold, lib3m, ted')
	
	sigult_cols = [open, high, low, close, volume, fir, gold, usd, lib3m, ted, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bgu_ted_m3_D, sigult_cols, 19, 'stocks, ir, gold, usd, lib3m, ted')
	
	biugltv_cols = [bond,fir,usd,gold, lib3m, ted, vix, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bt3m_vix_D, biugltv_cols, 20, 'bonds, ir, usd, gold, lib3m, ted, vix')
	
	sibgltv_cols = [open, high, low, close, volume, fir, bond, gold, lib3m, ted, vix, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bt3m_vix_D, sibgltv_cols, 21, 'stocks, ir, bonds, gold, lib3m, ted, vix')
	
	sigultv_cols = [open, high, low, close, volume, fir, gold, usd, lib3m, ted, vix, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bt3m_vix_D, sigultv_cols, 22, 'stocks, ir, gold, usd, lib3m, ted, vix')
	
	biugltvc_cols = [bond,fir,usd,gold, lib3m, ted, vix, crb, b_m_5, b_m_10, b_m_20, b_m_40, u_m_5, u_m_10, u_m_20, u_m_40]
	stockModelRunner(bv_crb_D, biugltvc_cols, 23, 'bonds, ir, usd, gold, lib3m, ted, vix, crb')
	
	sibgltvc_cols = [open, high, low, close, volume, fir, bond, gold, lib3m, ted, vix, crb, b_m_5, b_m_10, b_m_20, b_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	usdModelRunner(bv_crb_D, sibgltvc_cols, 24, 'stocks, ir, bonds, gold, lib3m, ted, vix, crb')
	
	sigultvc_cols = [open, high, low, close, volume, fir, gold, usd, lib3m, ted, vix, crb, u_m_5, u_m_10, u_m_20, u_m_40, st_m_5, st_m_10, st_m_20, st_m_40]
	bondModelRunner(bv_crb_D, sigultvc_cols, 25, 'stocks, ir, gold, usd, lib3m, ted, vix, crb')
	
	print('DNNReg_results: end of program', dnnRegModData)
	print('DNNClassification_results: end of program', dnnClModData)
	print('LinearClassification_results: end of program', LinClModData)
	print('Custom_Classificationn: end of program', custModClData)
	print('Custom_Regression: end of program', custModRegData)
	
		
if __name__ == "__main__":
	tf.app.run()
	
	